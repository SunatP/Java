Added tags.train.csv to "small" case as additional info for bonus credit. Each line in the file has the following format:
<uid>,<mid>,<tag>,<timestamp>

E.g., 21,527,drama,1429825935

You may use this file for training process.



Fixed the following movies in movies.csv:
@Error:25936,"Babe Ruth Story, The (1948) ",Drama
@Error:58404,Justice League: The New Frontier (2008) ,Action|Adventure|Animation|Fantasy|Sci-Fi
@Error:89045,Rocky VI (1986) ,Comedy
@Error:89722,"Horrible Way to Die, A (2010) ",Horror|Thriller
@Error:92214,"Poseidon Adventure, The (2005) ",Action|Adventure|Drama
@Error:94494,96 Minutes (2011) ,Drama|Thriller
@Error:94556,Citizen Gangster (2011) ,Crime|Drama
@Error:100240,"Woman's Face, A (En kvinnas ansikte) (1938) ",Drama
@Error:100308,Pressure Point  (1962) ,Drama
@Error:102084,Justice League: Doom (2012) ,Action|Animation|Fantasy
@Error:102920,Dark Circles (2013) ,Horror
@Error:104861,I Spit on Your Grave 2 (2013) ,Crime|Horror|Thriller
@Error:105497,Kumail Nanjiani: Beta Male (2013) ,Comedy|Documentary
@Error:108548,"Big Bang Theory, The (2007-)",Comedy
@Error:108583,Fawlty Towers (1975-1979),Comedy
@Error:108938,Aliyah (Alyah) (2012) ,Drama
@Error:126929,Li'l Quinquin,(no genres listed)
@Error:146344,Elämältä kaiken sain,Comedy|Drama