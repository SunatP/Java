/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LetterPrinter;

import static java.time.Clock.system;

/**
 *
 * @author Acer-
 */
public class LetterPrinter {
    public static void main (String[] args){
    System.out.println("XXXX");
    System.out.println("X");
    System.out.println("XXXX");
    System.out.println("   X");
    System.out.println("XXXX");
}
}
