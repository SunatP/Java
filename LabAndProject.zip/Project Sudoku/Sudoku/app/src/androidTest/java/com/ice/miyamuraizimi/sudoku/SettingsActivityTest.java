package com.ice.miyamuraizimi.sudoku;

import junit.framework.TestCase;

/**
 * Created by miyamuraizimi on 4/11/2558.
 */
public class SettingsActivityTest extends TestCase {

    public void testOnCreate() throws Exception {

    }

    public void testGetOptionMusic() throws Exception {

    }

    public void testGetOptionHints() throws Exception {

    }
}