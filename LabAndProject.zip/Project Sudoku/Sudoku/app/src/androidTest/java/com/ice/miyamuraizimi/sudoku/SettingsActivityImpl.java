package com.ice.miyamuraizimi.sudoku;

/**
 * Created by miyamuraizimi on 4/11/2558.
 */
public class SettingsActivityImpl extends SettingsActivity {
}
