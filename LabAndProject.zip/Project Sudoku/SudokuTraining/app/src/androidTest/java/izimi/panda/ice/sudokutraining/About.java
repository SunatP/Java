package izimi.panda.ice.sudokutraining;

import android.app.Activity;
import android.os.Bundle;

public class About extends Activity {

    public About() {
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(2130903040);
    }
}