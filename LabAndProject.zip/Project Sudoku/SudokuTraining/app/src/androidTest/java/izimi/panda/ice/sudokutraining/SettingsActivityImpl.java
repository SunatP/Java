package izimi.panda.ice.sudokutraining;

/**
 * Created by miyamuraizimi on 4/11/2558.
 */
public class SettingsActivityImpl extends SettingsActivity {
}
